<?php
// Конфигурация S3
define('S3_ACCESS_KEY', '03H86PL3LMB9M12SHAGQ');
define('S3_SECRET_KEY', 'jT1IcBXc2Bv2HKh4d8rK0jttG7h9lxvzzuKbhzai');
define('S3_ENDPOINT', 's3.regru.cloud');
define('S3_BUCKET', 'dorama-shorts');
define('S3_REGION', 'ru-1');
define('S3_PUBLIC_URL', 'https://s3.regru.cloud/dorama-shorts/');
?>